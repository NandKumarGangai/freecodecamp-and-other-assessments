import React from "react";

const validatePassword = (password) => {
  let characteristicsMatched = 0;

  if(password?.length >= 8) {
    characteristicsMatched = characteristicsMatched + 1;
  }

  if (/[A-Z]/.test(password)) {
    characteristicsMatched = characteristicsMatched + 1;
  }

  if (/[a-z]/.test(password)) {
    characteristicsMatched = characteristicsMatched + 1;
  }

  if (/[0-9]/.test(password)) {
    characteristicsMatched = characteristicsMatched + 1;
  }

  const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;

  if (specialChars.test(password)) {
    characteristicsMatched = characteristicsMatched + 1;
  }

  if (characteristicsMatched !== 0 && characteristicsMatched === 5) {
    return {
      bgColor: "green",
      text: "Strong Password"
    }
  }

  if (characteristicsMatched !== 0 && characteristicsMatched <= 4 && characteristicsMatched > 2) {
    return {
      bgColor: "orange",
      text: "Moderate Password"
    }
  }

  return {
    bgColor: "red",
    text: "Weak Password"
  };
}

const PasswordStrength = ({ password }) => {
  const validation = validatePassword(password);

  return (
    <div
      className="px-5 py-5"
      style={{
        backgroundColor: validation?.bgColor,
      }}
      data-testid="passwordStrengthDiv"
    >
      <h4
        style={{
          color: "white",
          textAlign: "center",
        }}
      >
        {validation?.text}
      </h4>
    </div>
  );
};

export default PasswordStrength;
